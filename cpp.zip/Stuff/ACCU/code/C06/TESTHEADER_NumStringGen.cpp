//: .\C06:TESTHEADER_NumStringGen.cpp
//: C06:NumStringGen.h
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// A random number generator that produces
// strings representing floating-point numbers.
// Number of digits to make
// Don't want a zero as the first digit
// Now assign the rest
// Insert a decimal point
// NUMSTRINGGEN_H ///:~
#include"NumStringGen.h"
int main() {}
