//: .\C05:TESTHEADER_BearCorner.cpp
//: C05:BearCorner.h
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// Item classes (traits of guests):
// Guest classes:
// Primary traits template (empty-could hold common types)
// Traits specializations for Guest types
// BEARCORNER_H ///:~
#include"BearCorner.h"
int main() {}
